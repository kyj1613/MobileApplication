package lecture.mobile.afinal.ma02_20160938;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MyCursorAdapter extends CursorAdapter {
    LayoutInflater inflater;
    Cursor cursor;
    int layout;

    public MyCursorAdapter(Context context, int layout, Cursor c) {
        super(context, c, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.layout = layout;
        cursor = c;
    }

    public void bindView(View view, Context context, Cursor cursor) {
        //TextView tvContactId = (TextView)view.findViewById(R.id.tvId);
        TextView tvContactTitle = (TextView)view.findViewById(R.id.tvTitle);
        TextView tvContactTerm = (TextView)view.findViewById(R.id.tvTerm);
        ImageView ivContactPeople = (ImageView) view.findViewById(R.id.ivPeople);

        //tvContactId.setText(cursor.getString(0));
        tvContactTitle.setText(cursor.getString(1));

        String term = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_STARTDATE));
        term += " ~ " + cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_ENDDATE));
        tvContactTerm.setText(term);

        String people = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_PEOPLE));
        if(Integer.parseInt(people) == 1)
            ivContactPeople.setImageResource(R.mipmap.person);
        else if(Integer.parseInt(people) == 2)
            ivContactPeople.setImageResource(R.mipmap.people2);
        else
            ivContactPeople.setImageResource(R.mipmap.people4);

    }

    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        View listItemLayout = inflater.inflate(R.layout.custom_adapter_view, parent, false);

        return listItemLayout;
    }
}
