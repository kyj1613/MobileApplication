package lecture.mobile.afinal.ma02_20160938;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AllContactsOnMapActivity extends AppCompatActivity {
    public final static String TAG = "AllContactOnMap";
    public final static int DEFAULT_ZOOM_LEVEL = 17;
    // permission 요청 코드
    private final static int PERMISSION_REQ_CODE = 100;

    private ContactDBHelper helper;
    private String urlString;
    private EditText etKeyword;

    //    private FakeParser parser;
    private Geocoder geoCoder;
    private GoogleMap googleMap;
    private LocationManager locManager;

    /*롱클릭된 위치 마커 관련 멤버 변수*/
    private MarkerOptions centerMarkerOptions;
    private Marker centerMarker;

    /*POI 위치 마커 관련 멤버 변수*/
    private MarkerOptions poiMarkerOptions;
    ArrayList<Marker> markerList;

    List<Address> addressList = null; //지오코딩한 결과 담는 리스트
    LatLng currentLoc = null;         //현재 위치의 위도 경도를 담는 객체

    public ArrayList<POI> arrayList;
    String id;
    String name;
    String address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_on_map);

        Intent intent2 = getIntent();

        helper = new ContactDBHelper(this);
        /*LocationManager 준비*/
        locManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        arrayList = new ArrayList<POI>();
        getAllList();
        /*구글맵 준비*/
        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(mapReadyCallBack);

        /*지오코더 준비*/
        geoCoder = new Geocoder(this);

        //  permission 요청
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISSION_REQ_CODE);
            return;
        }


        String url = "fake url";
        new NetworkAsyncTask().execute(url);
    }

    private ArrayList<POI> getAllList() {
        SQLiteDatabase db = helper.getReadableDatabase();

        int cnt = 0;
        Cursor cursor = db.query(helper.TABLE_EAT, null, null, null, null, null, null, null);
        cursor.moveToFirst();
        while (cursor.moveToNext()) {
            POI item = new POI();

            name = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_NAME));
            address = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_ADDRESS));

            item.set_id(Integer.parseInt(String.valueOf(cnt)));
            item.setName(name);
            item.setAddress(address);

            arrayList.add(item);
            cnt++;
        } int last = cnt;
        cursor = db.query(helper.TABLE_TOUR, null, null, null, null, null, null, null);
        cursor.moveToFirst();
        while (cursor.moveToNext()) {
            POI item = new POI();

            name = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_NAME));
            address = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_ADDRESS));

            item.set_id(Integer.parseInt(String.valueOf(cnt-last)));
            item.setName(name);
            item.setAddress(address);

            arrayList.add(item);
            cnt++;
        }
        cursor = db.query(helper.TABLE_REST, null, null, null, null, null, null, null);
        cursor.moveToFirst();
        while (cursor.moveToNext()) {
            POI item = new POI();

            name = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_NAME));
            address = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_ADDRESS));

            item.set_id(Integer.parseInt(String.valueOf(cnt-last)));
            item.setName(name);
            item.setAddress(address);

            arrayList.add(item);
            cnt++;
        }
        cursor.close();

        return arrayList;
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnRight:
                startActivity(new Intent(AllContactsOnMapActivity.this, MainActivity.class));
                overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_right);
                finish();
                break;
        }
    }

    String target_name;
    OnMapReadyCallback mapReadyCallBack = new OnMapReadyCallback() {
        @Override
        public void onMapReady(GoogleMap map) {
            googleMap = map;

            //마커를 클릭했을 때
            googleMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                @Override
                public boolean onMarkerClick(Marker marker) {
                    marker.showInfoWindow(); //클릭된 마커의 infoWindow보이기
                    return false;
                }
            });

            //마커의 infoWindow클릭했을 때
            googleMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
                @Override
                public void onInfoWindowClick(Marker marker) {
                    for(int i = 0; i < arrayList.size(); i++) {
                       if((arrayList.get(i).getAddress()).equals(marker.getTitle())) {
                           target_name= arrayList.get(i).getName();
                           break;
                       }
                    }
                    Toast.makeText(AllContactsOnMapActivity.this, marker.getTitle(), Toast.LENGTH_SHORT).show();
                    /*Intent intent = new Intent(AllContactsOnMapActivity.this, DetailContactActivity.class);
                    intent.putExtra("_id", target_id);
                    startActivity(intent);*/
                    return;
                }
            });
        }
    };

    /*Location Listener*/
    LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            LatLng currentLoc = new LatLng(location.getLatitude(), location.getLongitude());
            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLoc, 15));

            centerMarker.setPosition(currentLoc);
        }

        @Override
        public void onStatusChanged(String s, int i, Bundle bundle) {

        }

        @Override
        public void onProviderEnabled(String s) {

        }

        @Override
        public void onProviderDisabled(String s) {

        }
    };


    class NetworkAsyncTask extends AsyncTask<String, Integer, String> {

        public final static String TAG = "NetworkAsyncTask";
        private ProgressDialog apiProgressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            apiProgressDialog = ProgressDialog.show(AllContactsOnMapActivity.this, "Wait", "Downloading...");
        }

        @Override
        protected String doInBackground(String... strings) {
            /*NetworkAsyncTask 는 네트워크 작업을 실제 실행하지는 않으며 잠시 시간 대기만 수행*/
            try {
                Thread.sleep(1500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return "Open API search is completed";
        }

        @Override
        protected void onPostExecute(String result) {
            ArrayList<POI> pList = arrayList;

            double latitude; //위도
            double longitude; //경도
            poiMarkerOptions = new MarkerOptions();
            markerList = new ArrayList<Marker>(); //마커들 담는 ArrayList

            int i = 0;
            while (i < pList.size()) { //pList의 크기만큼 loop
                try {
                    //pList에 있는 각각의 원소의 주소값을 지오코딩하여 addressList에 추가
                    addressList = geoCoder.getFromLocationName(pList.get(i).getAddress(), 1);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (addressList == null) {
                    Toast.makeText(AllContactsOnMapActivity.this, "no result!", Toast.LENGTH_SHORT).show();
                    return;
                }
                int j = 0;
                for (Address address : addressList) {
                    latitude = address.getLatitude();   //지오코딩한 주소값의 위도
                    longitude = address.getLongitude(); //지오코딩한 주소값의 경도
                    currentLoc = new LatLng(latitude, longitude);

                    //MarkerOptions 정보 설정
                    poiMarkerOptions.position(currentLoc);      //MarkerOptions의 위치설정
                    poiMarkerOptions.title(address.getAddressLine(j));  //title에 주소설정
                    poiMarkerOptions.snippet(address.getPostalCode());  //snippet에 우편번호 설정
                    poiMarkerOptions.icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_launcher));

                    centerMarker = googleMap.addMarker(poiMarkerOptions);   //지도에 추가된 마커를 centerMarker에 등록
                    markerList.add(centerMarker);                             //centerMarker를 markerList에 추가

                    //카메라 움직임
                    googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLoc, 15));
                    j++;
                }
                i++;
            }
            apiProgressDialog.dismiss();

        }
    }

    //  permission 사용자 확인 결과 처리
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQ_CODE:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED
                        && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Permission was granted!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Permission was denied!", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }
}