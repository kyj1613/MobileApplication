package lecture.mobile.afinal.ma02_20160938.model;

public class Items {
    private String category;

    private String title;

    private String address;

    private String description;

    private String link;

    private String roadAddress;

    private String telephone;

    private String mapx;

    private String mapy;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getRoadAddress() {
        return roadAddress;
    }

    public void setRoadAddress(String roadAddress) {
        this.roadAddress = roadAddress;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getMapx() {
        return mapx;
    }

    public void setMapx(String mapx) {
        this.mapx = mapx;
    }

    public String getMapy() {
        return mapy;
    }

    public void setMapy(String mapy) {
        this.mapy = mapy;
    }

    @Override
    public String toString() {
        return "ClassPojo [category = " + category + ", title = " + title + ", address = " + address + ", description = " + description + ", link = " + link + ", roadAddress = " + roadAddress + ", telephone = " + telephone + ", mapx = " + mapx + ", mapy = " + mapy + "]";
    }
}