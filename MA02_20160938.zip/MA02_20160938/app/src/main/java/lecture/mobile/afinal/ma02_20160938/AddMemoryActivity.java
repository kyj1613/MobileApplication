package lecture.mobile.afinal.ma02_20160938;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import lecture.mobile.afinal.ma02_20160938.model.Items;
import lecture.mobile.afinal.ma02_20160938.model.NaverRoot;
import lecture.mobile.afinal.ma02_20160938.remote.INaverAPIService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class AddMemoryActivity extends AppCompatActivity {
    ContactDBHelper helper;
    RadioGroup rg;
    String index;
    SQLiteDatabase db;

    private final static int REQUEST_TAKE_THUMBNAIL = 100;
    private static final int REQUEST_TAKE_PHOTO = 200;
    private final static int PERMISSION_REQ_CODE = 300;
    private final static int PICK_FROM_ALBUM = 400;
    private String mCurrentPhotoPath;

    ImageView ivPhoto;
    EditText etName;
    TextView tvAddress;
    RatingBar rbRating;
    EditText etMemo;
    String name;
    String address;
    Float eval;
    String memo;

    //String address;     //openAPI를 요청할 url
    String clientId;    //API를 요청할 때 필요한 client Id
    String clientSecret; //API를 요청할 때 필요한 client Secret값
    String data;
    String keyword;
    ArrayList<MyTourData> resultList2;
    int id;

    Retrofit retrofit;
    private INaverAPIService mRetrofitService;  //OpenAPI Interface
    String apiURI;  //OpenAPI를 요청할 URL
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_memory);

        clientId = getResources().getString(R.string.client_id);
        clientSecret = getResources().getString(R.string.client_secret);

        helper = new ContactDBHelper(this);

        Intent intent = getIntent();
        id = intent.getIntExtra("_id", -1);Log.d("_ID", String.valueOf(id));
        db = helper.getReadableDatabase();

        ivPhoto = (ImageView)findViewById(R.id.ivPhoto);
        File path = getExternalFilesDir(Environment.DIRECTORY_PICTURES);

        Log.d("test", path.getAbsolutePath());

        ivPhoto.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
//                    외부 카메라 호출
                   /* Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(takePictureIntent, REQUEST_TAKE_THUMBNAIL);
                    }
                    return true;*/
                    dispatchTakePictureIntent();
                }
                return false;
            }
        });


        etName = (EditText)findViewById(R.id.etName);
        tvAddress = (TextView)findViewById(R.id.tvAddress);
        rbRating = (RatingBar)findViewById(R.id.rating);
        etMemo = (EditText)findViewById(R.id.etMemo);
        rg = (RadioGroup) findViewById(R.id.radioGroup1);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton radio_btn = (RadioButton) findViewById(checkedId);
                index = radio_btn.getText().toString();
            }
        });

        SQLiteDatabase db = helper.getReadableDatabase();

        String selection = ContactDBHelper.COL_ID + "=?";
        String[] selectionArgs = new String[]{String.valueOf(id)};

        Cursor cursor = db.query(ContactDBHelper.TABLE_LIST, new String[]{ContactDBHelper.COL_AREA},
                selection, selectionArgs, null, null, null, null);

        ListDTO item = new ListDTO();
        while(cursor.moveToNext()) {
            item.setId(id);
            data = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_AREA));
            item.setArea(data);
        }
        cursor.close();
        helper.close();

        apiURI = getResources().getString(R.string.api_url);
        if (retrofit == null){
            try {
                retrofit = new Retrofit.Builder()
                        .baseUrl(apiURI)    //OpenAPI의 기본 URL
                        .addConverterFactory(GsonConverterFactory.create())     //JSON 컨버터 지정
                        .build();
            } catch (Exception e){
                e.printStackTrace();
            }
        }
        mRetrofitService = retrofit.create(INaverAPIService.class);  //사용자가 지정한 인터페이스 서비스 생성
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
                ex.printStackTrace();
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "lecture.mobile.afinal.ma02_20160938.fileprovider", photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO);
            }
        }
    }

    private void setPic() {
        // Get the dimensions of the View
        int targetW = ivPhoto.getWidth();//mImageView.getWidth();
        int targetH = ivPhoto.getHeight();//mImageView.getHeight();

        // Get the dimensions of the bitmap
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(mCurrentPhotoPath, bmOptions);
        int photoW = bmOptions.outWidth;
        int photoH = bmOptions.outHeight;

        // Determine how much to scale down the image
        int scaleFactor = Math.min(photoW/targetW, photoH/targetH);

        // Decode the image file into a Bitmap sized to fill the View
        bmOptions.inJustDecodeBounds = false;
        bmOptions.inSampleSize = scaleFactor;
//        bmOptions.inPurgeable = true;

        Bitmap bitmap = BitmapFactory.decodeFile(mCurrentPhotoPath, bmOptions);
        ivPhoto.setImageBitmap(bitmap);
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = image.getAbsolutePath();
        return image;
    }

    private void galleryAddPic() {
        Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        File f = new File (mCurrentPhotoPath);
        Uri contentUri = Uri.fromFile(f);
        mediaScanIntent.setData(contentUri);
        this.sendBroadcast(mediaScanIntent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_TAKE_THUMBNAIL && resultCode == RESULT_OK) {
            //Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            //if(takePictureIntent.resolveActivity(getPackageManager()) != null) {
            //    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE); }
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap)extras.get("data");
            ivPhoto.setImageBitmap(imageBitmap);

        } else if (requestCode == REQUEST_TAKE_PHOTO && resultCode == RESULT_OK) {
            setPic();
        }
    }

    private void addEat() {
        SQLiteDatabase db = helper.getWritableDatabase();

        name = etName.getText().toString();
        address = tvAddress.getText().toString();
        eval = rbRating.getRating();
        memo = etMemo.getText().toString();

        ContentValues row = new ContentValues();
        row.put(ContactDBHelper.COL_NAME, name);
        row.put(ContactDBHelper.COL_PATH, mCurrentPhotoPath);
        row.put(ContactDBHelper.COL_ADDRESS, address);
        row.put(ContactDBHelper.COL_STAR, eval.toString());
        row.put(ContactDBHelper.COL_MEMO, memo);
        row.put(ContactDBHelper.COL_LISTID, String.valueOf(id));

        db.insert(ContactDBHelper.TABLE_EAT, null, row);

        helper.close();
    }

    private void addTour() {
        SQLiteDatabase db = helper.getWritableDatabase();

        name = etName.getText().toString();
        address = tvAddress.getText().toString();
        eval = rbRating.getRating();
        memo = etMemo.getText().toString();

        ContentValues row = new ContentValues();
        row.put(ContactDBHelper.COL_NAME, name);
        row.put(ContactDBHelper.COL_PATH, mCurrentPhotoPath);
        row.put(ContactDBHelper.COL_ADDRESS, address);
        row.put(ContactDBHelper.COL_STAR, eval.toString());
        row.put(ContactDBHelper.COL_MEMO, memo);
        row.put(ContactDBHelper.COL_LISTID, String.valueOf(id));

        db.insert(ContactDBHelper.TABLE_TOUR, null, row);

        helper.close();
    }

    private void addRest() {
        SQLiteDatabase db = helper.getWritableDatabase();

        name = etName.getText().toString();
        address = tvAddress.getText().toString();
        eval = rbRating.getRating();
        memo = etMemo.getText().toString();

        ContentValues row = new ContentValues();
        row.put(ContactDBHelper.COL_NAME, name);
        row.put(ContactDBHelper.COL_PATH, mCurrentPhotoPath);
        row.put(ContactDBHelper.COL_ADDRESS, address);
        row.put(ContactDBHelper.COL_STAR, eval.toString());
        row.put(ContactDBHelper.COL_MEMO, memo);
        row.put(ContactDBHelper.COL_LISTID, String.valueOf(id));

        db.insert(ContactDBHelper.TABLE_REST, null, row);

        helper.close();
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnAdd:
                if(index.equals("맛집"))
                    addEat();
                else if(index.equals("여행지"))
                    addTour();
                else if(index.equals("숙박"))
                    addRest();

                Toast.makeText(this, "추억이 추가되었습니다.", Toast.LENGTH_SHORT).show();

                AlertDialog.Builder builder = new AlertDialog.Builder(AddMemoryActivity.this);
                builder.setTitle("여행 추억 추가");
                builder.setMessage("여행 추억을 계속 추가하시겠습니까?");
                builder.setPositiveButton("아니오", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent2 = new Intent(AddMemoryActivity.this, MainActivity.class);
                        startActivity(intent2);
                    }
                });
                builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent2 = new Intent(AddMemoryActivity.this, AddMemoryActivity.class);
                        intent2.putExtra("_id", id);
                        startActivity(intent2);
                    }
                });
                builder.show();
                break;
            case R.id.btnCancel:
                if(mCurrentPhotoPath == null) {}
                else {
                    File file = new File(mCurrentPhotoPath);
                    if (file.exists())
                        file.delete();
                }
                finish();
                break;
            case R.id.btnRgsAdr:
                name = etName.getText().toString();
                String rslt = data + " " + name;
                Log.d("TAG", rslt);

                if(index == null)
                    Toast.makeText(this, "카테고리를 먼저 눌러주세요!", Toast.LENGTH_SHORT).show();
                else if(index.equals("맛집")) {
                    try {
                        keyword = URLEncoder.encode(rslt, "UTF-8"); //검색할 주소일부와 " 맛집"문자열을 합쳐서 인코딩함
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }

                    if (name.equals("")) Toast.makeText(this, "장소명을 입력하세요.", Toast.LENGTH_SHORT).show();
                    else {
                        Call<NaverRoot> apiCall = mRetrofitService.getItemsResult(rslt, clientId, clientSecret); //OpenAPI 서비스 요청에 필요한 값 전달
                        apiCall.enqueue(apiCallback);   //OpenAPI 응답 처리 객체, 서버 요청을 비동기로 처리
                    }
                }
                else if(index.equals("여행지")) {
                    try {
                        keyword = URLEncoder.encode(name, "UTF-8"); //여행지역과 " 맛집"문자열을 합쳐서 인코딩함
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }

                    if (name.equals("")) Toast.makeText(this, "장소명을 입력하세요.", Toast.LENGTH_SHORT).show();
                    else {
                        String addr;
                        addr = "http://api.visitkorea.or.kr/openapi/service/rest/KorService/searchKeyword?";
                        addr += "serviceKey=xoflh7EFyBviOqt%2FgsA5oi3qCbGa6JFnjFnDQC3ZwHpYEaY2cuRsoRLtzIflwugxZs5hZjoEwj2unEC8QtJz5g%3D%3D";
                        addr += "&MobileApp=report02_02_20160938&MobileOS=AND&keyword=";
                        addr += keyword;

                        new AddMemoryActivity.NetworkTourAsyncTask().execute(addr);
                    }    // address에 입력한 검색어를 인코딩한 값을 결합한 후 AsyncTask 실행
                }
                else if(index.equals("숙박")) {
                    try {
                        keyword = URLEncoder.encode(rslt, "UTF-8"); //검색할 주소일부와 " 맛집"문자열을 합쳐서 인코딩함
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }

                    if (name.equals("")) Toast.makeText(this, "장소명을 입력하세요.", Toast.LENGTH_SHORT).show();
                    else {
                        Call<NaverRoot> apiCall = mRetrofitService.getItemsResult(rslt, clientId, clientSecret); //OpenAPI 서비스 요청에 필요한 값 전달
                        apiCall.enqueue(apiCallback);   //OpenAPI 응답 처리 객체, 서버 요청을 비동기로 처리
                    }
                }
                rslt = null;
                break;
        }
    }

    //OpenAPI 응답 처리 객체 생성
    Callback<NaverRoot> apiCallback = new Callback<NaverRoot>() {
        @Override
        public void onResponse(Call<NaverRoot> call, Response<NaverRoot> response) {
            if (response.isSuccessful()){
                StringBuilder result = new StringBuilder();
                NaverRoot root = response.body();
                //for (int i = 0; i < root.getItems().size(); i++) {
                if(root.getItems().size() == 0)
                    Toast.makeText(AddMemoryActivity.this, "주소가 없습니다.", Toast.LENGTH_SHORT).show();
                else {
                    Items items = root.getItems().get(0);
                    result.append(items.getAddress() + "\n\n");
                    tvAddress.setText(result.toString());
                }
            }
        }

        @Override
        public void onFailure(Call<NaverRoot> call, Throwable t) {
            Log.e("TAG", "failure");
            Log.e("TAG", t.getMessage());
        }
    };

    //      openAPI 요청
    class NetworkTourAsyncTask extends AsyncTask<String, Integer, String> {
        public final static String TAG = "NetworkTourAsyncTask";
        public final static int TIME_OUT = 10000;
        ProgressDialog progressDlg;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDlg = ProgressDialog.show(AddMemoryActivity.this, "Wait", "Downloading...");     // 진행상황 다이얼로그 출력
        }
        @Override
        protected String doInBackground(String... strings) {
            String _address = strings[0];
            StringBuilder result = new StringBuilder();
            BufferedReader br = null;
            HttpURLConnection conn = null;

            try {
                URL url = new URL(_address);
                conn = (HttpURLConnection)url.openConnection();

                if (conn != null) {
                    conn.setConnectTimeout(TIME_OUT);
                    conn.setUseCaches(false);
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                        for (String line = br.readLine(); line != null; line = br.readLine()) {
                            result.append(line + '\n');
                        }
                    }
                }
            } catch (MalformedURLException ex) {
                ex.printStackTrace();
                cancel(false);
            } catch (Exception ex) {
                ex.printStackTrace();
                cancel(false);
            } finally {
                try {
                    if (br != null)  br.close();
                    if (conn != null) conn.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return result.toString();
        }

        @Override
        protected void onPostExecute(String result) {
//          parser 생성 및 parsing 수행
            MyXmlParser parser = new MyXmlParser();
            resultList2 = parser.parse2(result);
//            어댑터에 이전에 보여준 데이터가 있을 경우 클리어
            if (!resultList2.isEmpty())
                tvAddress.setText(resultList2.get(0).getAddr());
//Log.d("addr", resultList2.get(0).getAddr());
//            진행상황 다이얼로그 종료
            progressDlg.dismiss();
        }
        @Override
        protected void onCancelled() {
            super.onCancelled();
            Toast.makeText(AddMemoryActivity.this, "Error!!!", Toast.LENGTH_SHORT).show();
            progressDlg.dismiss();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQ_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "외부저장소 쓰기 권한 획득!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "외부저장소 쓰기 권한 없음", Toast.LENGTH_SHORT).show();
                }
        }
    }

}
