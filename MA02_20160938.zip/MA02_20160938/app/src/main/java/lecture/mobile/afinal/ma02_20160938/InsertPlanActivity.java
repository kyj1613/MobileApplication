package lecture.mobile.afinal.ma02_20160938;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.GoogleApi;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;

import java.io.IOException;
import java.security.spec.ECField;
import java.util.List;
import java.util.Map;

import static lecture.mobile.afinal.ma02_20160938.AllContactsOnMapActivity.DEFAULT_ZOOM_LEVEL;

public class InsertPlanActivity extends AppCompatActivity {

    final int START_CODE = 100;
    final int END_CODE = 200;
    final int UPDATE_CODE = 300;
    private final static int PERMISSION_REQ_CODE = 1000;
    TextView tvStartDate;
    TextView tvEndDate;
    EditText etTitle;
    RadioGroup rg;
    String people;
    EditText etPlace;
    ContactDBHelper helper;
    Geocoder geoCoder; //서버에 요청..
    private GoogleMap mGoogleMap;
    MapFragment mapFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_plan);

        Intent intent = getIntent();

        tvStartDate = (TextView) findViewById(R.id.tvStartDate);
        tvEndDate = (TextView) findViewById(R.id.tvEndDate);
        etTitle = (EditText) findViewById(R.id.etTitle);
        rg = (RadioGroup) findViewById(R.id.radioGroup1);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton radio_btn = (RadioButton) findViewById(checkedId);
                people = radio_btn.getText().toString();
                if(people.equals(""))
                    Toast.makeText(InsertPlanActivity.this, "동행 인원을 선택해 주세요.", Toast.LENGTH_SHORT).show();
                else {
                    people = people.substring(0, 1);
                }
            }
        });
        etPlace = (EditText)findViewById(R.id.etPlace);

        helper = new ContactDBHelper(this);

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] {android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION }, PERMISSION_REQ_CODE);
            return;
        }
        geoCoder = new Geocoder(this);

    }

    public void onClick(View v) {
        Intent intent = new Intent(InsertPlanActivity.this, InsertDateActivity.class);
        switch (v.getId()) {
            case R.id.btnStartDate:
                startActivityForResult(intent, START_CODE);
                break;
            case R.id.btnEndDate:
                startActivityForResult(intent, END_CODE);
                break;
            case R.id.btnMap:
                mapFragment = (MapFragment)getFragmentManager().findFragmentById(R.id.map1);
                mapFragment.getMapAsync(mapReadyCallBack);

                break;
            case R.id.btnAdd:
                SQLiteDatabase db = helper.getWritableDatabase();

                String startDate = tvStartDate.getText().toString();
                String endDate = tvEndDate.getText().toString();
                String title = etTitle.getText().toString();
                String area = etPlace.getText().toString();

                ContentValues row = new ContentValues();
                row.put(ContactDBHelper.COL_TITLE, title);
                row.put(ContactDBHelper.COL_STARTDATE, startDate);
                row.put(ContactDBHelper.COL_ENDDATE, endDate);
                if(people.equals(""))
                    Toast.makeText(InsertPlanActivity.this, "인원을 선택해 주세요.", Toast.LENGTH_SHORT).show();
                else {
                    row.put(ContactDBHelper.COL_PEOPLE, people);
                }
                row.put(ContactDBHelper.COL_AREA, area);

                db.insert(ContactDBHelper.TABLE_LIST_PLAN, null, row);
//                db.insert(ContactDBHelper.TABLE_LIST, null, row);
                helper.close();
                Toast.makeText(this, "일정이 추가되었습니다!", Toast.LENGTH_SHORT).show();

                finish();
                break;
        }
    }


    OnMapReadyCallback mapReadyCallBack = new OnMapReadyCallback() {
        @Override
        public void onMapReady(GoogleMap googleMap) {
            mGoogleMap = googleMap;
            LatLng mLatLng = null;
            List<Address> addressList = null;
            String addressName = ((EditText)findViewById(R.id.etPlace)).getText().toString();

            if(addressName.equals(""))
                Toast.makeText(InsertPlanActivity.this, "장소를 입력해 주세요.", Toast.LENGTH_SHORT).show();
            else {
                try {
                    addressList = geoCoder.getFromLocationName(addressName, 5);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if (addressList == null) {
                Toast.makeText(InsertPlanActivity.this, "결과 없음", Toast.LENGTH_SHORT).show();
            } else {
                mLatLng = new LatLng(addressList.get(0).getLatitude(), addressList.get(0).getLongitude());
                mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(mLatLng, 10));
            }

        }
    };

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == START_CODE){
            switch (resultCode){
                case RESULT_OK:
                    int year = data.getIntExtra("year", 0);
                    int month = data.getIntExtra("month", 0);
                    int date = data.getIntExtra("dayOfMonth", 0);
                    String rslt = String.valueOf(year) + "-";
                    rslt += String.valueOf(month) + "-";
                    rslt += String.valueOf(date);
                    tvStartDate.setText(rslt);
                    break;
                case RESULT_CANCELED:
                    Toast.makeText(this, "출발일 선택 취소", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
        else if(requestCode == END_CODE){
            switch (resultCode){
                case RESULT_OK:
                    int year = data.getIntExtra("year", 0);
                    int month = data.getIntExtra("month", 0);
                    int date = data.getIntExtra("dayOfMonth", 0);
                    String rslt = String.valueOf(year) + "-";
                    rslt += String.valueOf(month) + "-";
                    rslt += String.valueOf(date);
                    tvEndDate.setText(rslt);
                    break;
                case RESULT_CANCELED:
                    Toast.makeText(this, "도착일 선택 취소", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    }

 /*   //  permission 사용자 확인 결과 처리
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQ_CODE:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED
                        && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Permission was granted!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Permission was denied!", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }*/
}
