package lecture.mobile.afinal.ma02_20160938;

public class POI {
    private int _id;
    private String name;
    private String address;
    private double latitude;
    private double longitude;


    public POI( String name, String phone, String address) {
        this.name = name;
        this.address = address;
    }

    public POI() { }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getName() {
        return name;
    }

    public void setName(String title) {
        this.name = name;
    }


    @Override
    public String toString() {
        return "POI{" +
                "title='" + name + '\'' +
                ", address='" + address + '\'' +
                '}';
    }
}
