package lecture.mobile.afinal.ma02_20160938;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ContactDBHelper extends SQLiteOpenHelper {
    private final static String DB_NAME = "contact_db";
    public final static String TABLE_LIST = "travel_table";
    public final static String TABLE_EAT = "restaurant_table";
    public final static String TABLE_TOUR = "tour_table";
    public final static String TABLE_REST = "hotel_table";
    public final static String TABLE_LIST_PLAN = "travel_plan_table";
    public final static String TABLE_EAT_PLAN = "restaurant_plan_table";
    public final static String TABLE_TOUR_PLAN = "tour_plan_table";
    public final static String TABLE_REST_PLAN = "hotel_plan_table";

    // travel_table columns
    public final static String COL_ID = "_id";
    public final static String COL_TITLE = "title";
    public final static String COL_PEOPLE = "people";
    public final static String COL_STARTDATE = "startdate";
    public final static String COL_ENDDATE = "enddate";
    public final static String COL_AREA = "area";


    //common columns
    public final static String COL_DID = "_dId";
    public final static String COL_NAME = "name";
    public final static String COL_ADDRESS = "address";
    public final static String COL_TEL = "tel";
    public final static String COL_STAR = "star";
    public final static String COL_MEMO = "memo";
    public final static String COL_PATH = "path";
    public final static String COL_LISTID = "listId";

    public ContactDBHelper(Context context) {
        super(context, DB_NAME, null, 1);
    }

    /*
                db.execSQL("create table " + TABLE_EAT + " (" + COL_ID + " INTEGER primary key autoincrement, " + COL_NAME + " TEXT, "
                + COL_ADDRESS + " TEXT, " + COL_TEL + " TEXT, " + COL_STAR + " TEXT, " + COL_MEMO + " TEXT, " + COL_LISTID + " INTEGER);");
                        db.execSQL("create table " + TABLE_TOUR + " (" + COL_ID + " INTEGER primary key autoincrement, "
                    + COL_NAME + " TEXT, " + COL_DEPT + " TEXT, " + COL_PHONE + " TEXT, " + COL_AREA + " TEXT, " + COL_PROFILE + " TEXT);");
                    */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_LIST + " (" + COL_ID + " INTEGER primary key autoincrement, "
                + COL_TITLE + " TEXT, " + COL_PEOPLE + " TEXT, " + COL_STARTDATE + " TEXT, " + COL_ENDDATE + " TEXT, " + COL_AREA + " TEXT);");

        db.execSQL("create table " + TABLE_EAT + " (" + COL_DID + " INTEGER primary key autoincrement, " + COL_NAME + " TEXT, "
                + COL_ADDRESS + " TEXT, " + COL_TEL + " TEXT, " + COL_STAR + " TEXT, " + COL_MEMO + " TEXT, " + COL_PATH + " TEXT, " + COL_LISTID + " INTEGER,"
                + " FOREIGN KEY (" + COL_LISTID + ") REFERENCES " + TABLE_LIST + "(" + COL_ID + "));");
        db.execSQL("create table " + TABLE_TOUR + " (" + COL_DID + " INTEGER primary key autoincrement, " + COL_NAME + " TEXT, "
                + COL_ADDRESS + " TEXT, " + COL_TEL + " TEXT, " + COL_STAR + " TEXT, " + COL_MEMO + " TEXT, " + COL_PATH + " TEXT, " + COL_LISTID + " INTEGER,"
                + " FOREIGN KEY (" + COL_LISTID + ") REFERENCES " + TABLE_LIST + "(" + COL_ID + "));");
        db.execSQL("create table " + TABLE_REST + " (" + COL_DID + " INTEGER primary key autoincrement, " + COL_NAME + " TEXT, "
                + COL_ADDRESS + " TEXT, " + COL_TEL + " TEXT, " + COL_STAR + " TEXT, " + COL_MEMO + " TEXT, " + COL_PATH + " TEXT, " + COL_LISTID + " INTEGER,"
                + " FOREIGN KEY (" + COL_LISTID + ") REFERENCES " + TABLE_LIST + "(" + COL_ID + "));");

        db.execSQL("create table " + TABLE_LIST_PLAN + " (" + COL_ID + " INTEGER primary key autoincrement, "
                + COL_TITLE + " TEXT, " + COL_PEOPLE + " TEXT, " + COL_STARTDATE + " TEXT, " + COL_ENDDATE + " TEXT, " + COL_AREA + " TEXT);");

//        db.execSQL("create table " + TABLE_EAT_PLAN + " (" + COL_DID + " INTEGER primary key autoincrement, " + COL_NAME + " TEXT, "
//                + COL_ADDRESS + " TEXT, " + COL_TEL + " TEXT, " + COL_STAR + " TEXT, " + COL_MEMO + " TEXT, " + COL_PATH + " TEXT, " + COL_LISTID + " INTEGER,"
//                + " FOREIGN KEY (" + COL_LISTID + ") REFERENCES " + TABLE_LIST_PLAN + "(" + COL_ID + "));");
        db.execSQL("create table " + TABLE_TOUR_PLAN + " (" + COL_DID + " INTEGER primary key autoincrement, " + COL_NAME + " TEXT, "
                + COL_ADDRESS + " TEXT, " + COL_TEL + " TEXT, " + COL_STAR + " TEXT, " + COL_MEMO + " TEXT, " + COL_PATH + " TEXT, " + COL_LISTID + " INTEGER,"
                + " FOREIGN KEY (" + COL_LISTID + ") REFERENCES " + TABLE_LIST_PLAN + "(" + COL_ID + "));");
//        db.execSQL("create table " + TABLE_REST_PLAN + " (" + COL_DID + " INTEGER primary key autoincrement, " + COL_NAME + " TEXT, "
//                + COL_ADDRESS + " TEXT, " + COL_TEL + " TEXT, " + COL_STAR + " TEXT, " + COL_MEMO + " TEXT, " + COL_PATH + " TEXT, " + COL_LISTID + " INTEGER,"
//                + " FOREIGN KEY (" + COL_LISTID + ") REFERENCES " + TABLE_LIST_PLAN + "(" + COL_ID + "));");

//		샘플 데이터
        db.execSQL("INSERT INTO " + TABLE_LIST + " VALUES (null, '포항 가족여행', '4', '2018-7-31', '2018-08-02', '포항');");
        db.execSQL("INSERT INTO " + TABLE_LIST + " VALUES (null, '강릉 우정여행', '4', '2018-12-11', '2018-12-12', '강릉');");

        db.execSQL("INSERT INTO " + TABLE_EAT + " VALUES (null, '마라도회식당', '경북 포항시 북구 해안로 217-1', '054-251-3850', '4', '회가 좋다', null, '1');");
        db.execSQL("INSERT INTO " + TABLE_EAT + " VALUES (null, '오도리오도시', '경북 포항시 북구 흥해읍 해안로1774번길 49-1', " +
                "'010-4908-3308', '3.0', '커피가 비쌈', null, '1');");

        db.execSQL("INSERT INTO " + TABLE_TOUR + " VALUES (null, '호미곶', '경상북도 포항시 남구 호미곶면 호미곶길 99', '054-284-5026', '4', '멋있다', null, '1');");
        db.execSQL("INSERT INTO " + TABLE_TOUR + " VALUES (null, '오어사', '경북 포항시 남구 오천읍 오어로1', '054-292-2083', '3', '절은 역시 절이다', null, '1');");

        db.execSQL("INSERT INTO " + TABLE_REST + " VALUES (null, '베스트 웨스턴', '경상북도 포항시 북구 두호동 367', '054-230-7000', '5', '깔끔 멋있 만족', null, '1');");
//        db.execSQL("INSERT INTO " + TABLE_REST + " VALUES (null, 'TT', '서울시 하월곡동', '02-3111-1111', '3', '조아요굿굿', null, '1');");

        //db.execSQL("INSERT INTO " + TABLE_LIST_PLAN + " VALUES (null, '정민이랑 여행', '2', '2019-1-1', '2019-1-3', '당진');");
//        db.execSQL("INSERT INTO " + TABLE_LIST_PLAN + " VALUES (null, '신년행', '2', '2018-12-30', '2018-12-31', '속초');");

        /*db.execSQL("INSERT INTO " + TABLE_EAT_PLAN + " VALUES (null, '향아식당', '충남 당진시', '041-1111-1111', '4', '조아요', null, '1');");
        db.execSQL("INSERT INTO " + TABLE_EAT_PLAN + " VALUES (null, '공', '서울시 하월곡동', '02-1111-1111', '3', '조아요굿굿', null, '1');");
*/
        //db.execSQL("INSERT INTO " + TABLE_TOUR_PLAN + " VALUES (null, '아미술관', '충남 당진시', '041-1211-1111', '4', '조아요', null, '1');");
        //db.execSQL("INSERT INTO " + TABLE_TOUR_PLAN + " VALUES (null, '덕', '서울시 하월곡동', '02-1211-1111', '3', '조아요굿굿', null, '1');");

        /*db.execSQL("INSERT INTO " + TABLE_REST_PLAN + " VALUES (null, 'M', '충남 당진시', '041-1311-1111', '4', '조아요', null, '1');");
        db.execSQL("INSERT INTO " + TABLE_REST_PLAN + " VALUES (null, 'T', '서울시 하월곡동', '02-3111-1111', '3', '조아요굿굿', null, '1');");
*/    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table " + TABLE_LIST);
        db.execSQL("drop table " + TABLE_EAT);
        db.execSQL("drop table " + TABLE_TOUR);
        db.execSQL("drop table " + TABLE_REST);
        db.execSQL("drop table " + TABLE_LIST_PLAN);
        db.execSQL("drop table " + TABLE_EAT_PLAN);
        db.execSQL("drop table " + TABLE_TOUR_PLAN);
        db.execSQL("drop table " + TABLE_REST_PLAN);
        onCreate(db);
    }

}

