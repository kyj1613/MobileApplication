package lecture.mobile.afinal.ma02_20160938;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MyPlanDetailAdapter extends BaseAdapter {
    private Context context;
    private int layout;
    private ArrayList<MyTourData> myDataList;
    private LayoutInflater layoutInflater;

    public MyPlanDetailAdapter(Context context, int layout, ArrayList<MyTourData> myDataList){
        this.context = context;
        this.layout = layout;
        this.myDataList = myDataList;
        layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return myDataList.size();
    }

    @Override
    public Object getItem(int position) {
        return myDataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return myDataList.get(position).get_id();
    }

    @Override
    public View getView(int pos, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = layoutInflater.inflate(layout, parent, false);

            holder = new ViewHolder();
            holder.title = (TextView)convertView.findViewById(R.id.tvTitle);
            holder.addr = (TextView)convertView.findViewById(R.id.tvAddr);
            holder.tel = (TextView)convertView.findViewById(R.id.tvTel);
            convertView.setTag(holder);
        }
        else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.title.setText(myDataList.get(pos).getTitle());
        holder.addr.setText(myDataList.get(pos).getAddr());
        holder.tel.setText(myDataList.get(pos).getTel());

        return convertView;
    }
    static class ViewHolder {
        TextView title;     //관광지명
        TextView addr;      //관광지주소
        TextView tel;       //관광지 전화번호
    }

    //어댑터 비우기
    public void clear() {
        myDataList.clear();
        notifyDataSetChanged();
    }

    //어댑터에 새로운 값 채워넣기
    public void addAll(ArrayList<MyTourData> newDataList) {
        myDataList.addAll(newDataList);
        notifyDataSetChanged();
    }
}
/*

    LayoutInflater inflater;
    Cursor cursor;
    int layout;

    public MyPlanDetailAdapter(Context context, int layout, Cursor c) {
        super(context, c, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.layout = layout;
        cursor = c;
    }

    public void bindView(View view, Context context, Cursor cursor) {
        TextView tvContactId = (TextView)view.findViewById(R.id.tvId);
        TextView tvContactTitle = (TextView)view.findViewById(R.id.tvTitle);
        TextView tvContactTerm = (TextView)view.findViewById(R.id.tvTerm);
        ImageView ivContactPeople = (ImageView) view.findViewById(R.id.ivPeople);

        tvContactId.setText(cursor.getString(0));
        tvContactTitle.setText(cursor.getString(1));

        String term = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_STARTDATE));
        term += " ~ " + cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_ENDDATE));
        tvContactTerm.setText(term);

        String people = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_PEOPLE));
        if(Integer.parseInt(people) == 1)
            ivContactPeople.setImageResource(R.mipmap.person);
        else if(Integer.parseInt(people) == 2)
            ivContactPeople.setImageResource(R.mipmap.people2);
        else
            ivContactPeople.setImageResource(R.mipmap.people4);

    }

    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        View listItemLayout = inflater.inflate(R.layout.custom_adapter_view, parent, false);

        return listItemLayout;
    }
}
*/
