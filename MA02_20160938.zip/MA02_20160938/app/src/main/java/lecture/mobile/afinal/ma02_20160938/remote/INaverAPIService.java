package lecture.mobile.afinal.ma02_20160938.remote;

import lecture.mobile.afinal.ma02_20160938.model.NaverRoot;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Query;

public interface INaverAPIService {
    @GET("/v1/search/local.json")
    Call<NaverRoot> getItemsResult(@Query("query") String text, @Header("X-Naver-Client-id") String id, @Header("X-Naver-Client-Secret") String secret);
}
