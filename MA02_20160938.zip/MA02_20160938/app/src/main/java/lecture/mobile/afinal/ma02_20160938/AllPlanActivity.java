package lecture.mobile.afinal.ma02_20160938;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class AllPlanActivity extends AppCompatActivity {

    ListView lvContacts = null;
    ContactDBHelper helper;
    Cursor cursor;
    MyCursorAdapter adapter;
    String area;

    @Override
    protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_plan);

        lvContacts = (ListView)findViewById(R.id.lvPlan);
        Intent newIntent = getIntent();

        helper = new ContactDBHelper(this);

//		  SimpleCursorAdapter 객체 생성
        adapter = new MyCursorAdapter (this, R.layout.custom_adapter_view, null);

        lvContacts.setAdapter(adapter);

        lvContacts.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int pos, long id) {

                final int index = (int)id;

                AlertDialog.Builder builder = new AlertDialog.Builder(AllPlanActivity.this);
                builder.setTitle("여행 일정 목록 삭제");
                builder.setMessage("정말 삭제하시겠습니까?");//cursor.getString(cursor.getColumnIndex("COL_NAME")) + "님을(를) 삭제하시겠습니까?");
                builder.setPositiveButton("삭제", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
//                        DB 삭제 수행
                        SQLiteDatabase db = helper.getWritableDatabase();
                        String whereClause = helper.COL_ID + "=?";
                        String[] whereArgs = new String[] { String.valueOf(index) };
                        db.delete(helper.TABLE_LIST_PLAN, whereClause, whereArgs);

                        refresh();
//                        새로운 DB 내용으로 리스트뷰 갱신
                    }
                });
                builder.setNegativeButton("취소", null);
                builder.show();

                return true;
            }
        });

        lvContacts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long id) {
//
                final int index = (int)id;
                Log.d("area", String.valueOf(index));
                SQLiteDatabase db = helper.getReadableDatabase();
                String whereClause = helper.COL_ID + "=?";
                String[] whereArgs = new String[] { String.valueOf(id) };

                cursor = db.query(helper.TABLE_LIST_PLAN, null, whereClause, whereArgs, null, null, null);

                cursor.moveToFirst();
                area = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_AREA));

                Intent intent = new Intent(AllPlanActivity.this, SearchPlanDetailActivity.class);
                intent.putExtra("_id", (int)index);
                intent.putExtra("area", area);
                startActivity(intent);
            }
        });
    }

    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btnAdd:
                Intent intent = new Intent(AllPlanActivity.this, InsertPlanActivity.class);
                startActivity(intent);
                break;
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
//        DB에서 데이터를 읽어와 Adapter에 설정
        refresh();
    }

    public void refresh() {
        SQLiteDatabase db = helper.getReadableDatabase();
        cursor = db.rawQuery("select * from " + ContactDBHelper.TABLE_LIST_PLAN, null);

        adapter.changeCursor(cursor);
        helper.close();
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
//        cursor 사용 종료
        if (cursor != null) cursor.close();
    }

}

