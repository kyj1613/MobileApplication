package lecture.mobile.afinal.ma02_20160938;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;

public class DetailContactActivity extends AppCompatActivity {
    ContactDBHelper helper;
    Button btnEat;
    Button btnTour;
    Button btnRest;
    SQLiteDatabase db;
    //MenuSlideView mSlideView;
    ArrayList<ContactDTO> contactList;
    //UI 관련
    private RecyclerView rv;
    private LinearLayoutManager mLinearLayoutManager;
    MyDetailAdapter adapter;

    String whereClause;
    String[] whereArgs;
    int id;
    final static int PERMISSION_REQ_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_contact);
        //mSlideView = (MenuSlideView)findViewById(R.id.detail_slide);

        contactList = new ArrayList<ContactDTO>();

        mLinearLayoutManager = new LinearLayoutManager(this);
       // mLinearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);

        rv = (RecyclerView) findViewById(R.id.rv);
        rv.setHasFixedSize(true);
        adapter = new MyDetailAdapter(this, contactList);
        Log.e("onCreate[noticeList]", "" + contactList.size());
        rv.setAdapter(adapter);
        rv.setLayoutManager(mLinearLayoutManager);


        helper = new ContactDBHelper(this);

        btnEat = (Button)findViewById(R.id.btnEat);
        btnTour = (Button) findViewById(R.id.btnTour);
        btnRest = (Button)findViewById(R.id.btnRest);

        Intent intent = getIntent();
        id = intent.getIntExtra("_id", -1);
        Log.d("TAG", String.valueOf(id));
        db = helper.getReadableDatabase();

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQ_CODE);
        }

        makeEatList();
    }

    private void makeEatList() {
        contactList.clear();
        whereClause = helper.COL_LISTID + "=?";
        whereArgs = new String[] { String.valueOf(id) };
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor cursor = db.query(helper.TABLE_EAT, null, whereClause, whereArgs, null, null, null, null);

        while(cursor.moveToNext()) {
            long id = cursor.getInt(cursor.getColumnIndex(ContactDBHelper.COL_DID));
            String path = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_PATH));
            String name = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_NAME));
            String address = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_ADDRESS));
            String star = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_STAR));
            String memo = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_MEMO));
            contactList.add ( new ContactDTO (id, name, path, address, star, memo) );
        }

        //adapter = new MyDetailAdapter(this, contactList);
        Log.e("onCreate[noticeList]", "" + contactList.size());
        //rv.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        cursor.close();
        helper.close();
    }

    private void makeTourList() {
        contactList.clear();
        whereClause = helper.COL_LISTID + "=?";
        whereArgs = new String[] { String.valueOf(id) };
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor cursor = db.query(helper.TABLE_TOUR, null, whereClause, whereArgs, null, null, null, null);

        while(cursor.moveToNext()) {
            long id = cursor.getInt(cursor.getColumnIndex(ContactDBHelper.COL_DID));
            String path = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_PATH));
            String name = cursor.getString(cursor.getColumnIndex("name"));
            String address = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_ADDRESS));
            String star = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_STAR));
            String memo = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_MEMO));
            contactList.add ( new ContactDTO (id, name, path, address, star, memo) );
        }

        //adapter = new MyDetailAdapter(this, contactList);
        Log.e("onCreate[noticeList]", "" + contactList.size());
        //rv.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        cursor.close();
        helper.close();
    }

    private void makeRestList() {
        contactList.clear();
        whereClause = helper.COL_LISTID + "=?";
        whereArgs = new String[] { String.valueOf(id) };Log.e("ididididid", "" + String.valueOf(id));
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor cursor = db.query(helper.TABLE_REST, null, whereClause, whereArgs, null, null, null, null);

        while(cursor.moveToNext()) {
            long id = cursor.getInt(cursor.getColumnIndex(ContactDBHelper.COL_DID));
            String path = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_PATH));
            String name = cursor.getString(cursor.getColumnIndex("name"));
            String address = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_ADDRESS));
            String star = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_STAR));
            String memo = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_MEMO));
            contactList.add ( new ContactDTO (id, name, path, address, star, memo) );
        }

        Log.e("onCreate[noticeList]", "" + contactList.size());

        adapter.notifyDataSetChanged();
        cursor.close();
        helper.close();
    }

    protected void onResume() {
        super.onResume();
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnEat:
                /*helper = new ContactDBHelper(this);
                db = helper.getReadableDatabase();

                whereClause = helper.COL_LISTID + "=?";
                whereArgs = new String[] { String.valueOf(id) };

                Cursor cursor = db.query(helper.TABLE_EAT, null, whereClause, whereArgs, null, null, null, null);
                cursor.moveToFirst();*/

/*                String name = cursor.getString(cursor.getColumnIndex("name"));
                String address = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_ADDRESS));
                String star = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_STAR));
                String memo = cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_MEMO));*/

                /*TextView tvName = (TextView) findViewById(R.id.tvName);
                TextView tvAddr = (TextView) findViewById(R.id.tvAddress);
                RatingBar rbRating = (RatingBar) findViewById(R.id.rating);
                TextView tvMemo = (TextView) findViewById(R.id.tvMemo);

                tvName.setText("name");
                tvAddr.setText("address");
                rbRating.setRating(Float.parseFloat("5"));
                tvMemo.setText("memo");*/

                //makeEatList();
                /*adapter = new MyDetailAdapter(this, contactList);
                Log.e("onCreate[noticeList]", "" + contactList.size());
                rv.setAdapter(adapter);*/

                //카드 리스트뷰 어댑터에 연결
              /*  MyDetailAdapter adapter = new MyDetailAdapter(this, contactList);
                //Log.e("onCreate[noticeList]", "" + contactList.size());
                rv.setAdapter(adapter);*/
                makeEatList();
                //adapter.notifyDataSetChanged();
                break;
            case R.id.btnTour:
                makeTourList();
                //adapter.notifyDataSetChanged();
                break;
            case R.id.btnRest:
                makeRestList();
                //adapter.notifyDataSetChanged();
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQ_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "외부저장소 쓰기 권한 획득!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "외부저장소 쓰기 권한 없음", Toast.LENGTH_SHORT).show();
                }

        }
    }
}
