package lecture.mobile.afinal.ma02_20160938;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import lecture.mobile.afinal.ma02_20160938.model.MyPlace;

public class DetailedInfoActivity extends AppCompatActivity {

    final static String TAG = "DetailedInfoActivity";

    MyPlace place;

    ContactDBHelper helper;
    RadioGroup rg;
    EditText etName;
    EditText etAddress;
    EditText etPhoneNumber;
    String index;
    SQLiteDatabase db;
    int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_info);

        helper = new ContactDBHelper(this);

        rg = (RadioGroup)findViewById(R.id.radioGroup1);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton radio_btn = (RadioButton) findViewById(checkedId);
                index = radio_btn.getText().toString();
            }
        });
        etName = (EditText)findViewById(R.id.etName);
        etAddress = (EditText)findViewById(R.id.etAddress);
        etPhoneNumber = (EditText)findViewById(R.id.etPhoneNumber);

        db = helper.getReadableDatabase();

//        intent가 저장하고 있는 place 객체 확인
        place = (MyPlace) getIntent().getSerializableExtra("place");
        id = getIntent().getIntExtra("_id", -1);
        Log.i(TAG, place.getName());
    }

    @Override
    protected void onResume() {
        super.onResume();

        etName.setText(place.getName());
        etAddress.setText(place.getAddress());
        etPhoneNumber.setText( (place.getPhone().equals("") ? "정보 없음" : place.getPhone()) );
    }

    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btnSave:
//                DB 에 저장하거나 수정할 경우 수행 코드 작성
                if(index.equals("맛집")) {
                    String name = etName.getText().toString();
                    String addr = etAddress.getText().toString();
                    String phone = etPhoneNumber.getText().toString();
                    String listId = String.valueOf(id);

                    ContentValues row = new ContentValues();
                    row.put(ContactDBHelper.COL_NAME, name);
                    row.put(ContactDBHelper.COL_ADDRESS, addr);
                    row.put(ContactDBHelper.COL_TEL, phone);
                    row.put(ContactDBHelper.COL_LISTID, listId);

                    db.insert(ContactDBHelper.TABLE_EAT_PLAN, null, row);
                    helper.close();
                }
                else if(index.equals("여행지"))
                {
                    String name = etName.getText().toString();
                    String addr = etAddress.getText().toString();
                    String phone = etPhoneNumber.getText().toString();
                    String listId = String.valueOf(id);

                    ContentValues row = new ContentValues();
                    row.put(ContactDBHelper.COL_NAME, name);
                    row.put(ContactDBHelper.COL_ADDRESS, addr);
                    row.put(ContactDBHelper.COL_TEL, phone);
                    row.put(ContactDBHelper.COL_LISTID, listId);

                    db.insert(ContactDBHelper.TABLE_TOUR_PLAN, null, row);
                    helper.close();
                }
                else if(index.equals("숙박"))
                {
                    String name = etName.getText().toString();
                    String addr = etAddress.getText().toString();
                    String phone = etPhoneNumber.getText().toString();
                    String listId = String.valueOf(id);

                    ContentValues row = new ContentValues();
                    row.put(ContactDBHelper.COL_NAME, name);
                    row.put(ContactDBHelper.COL_ADDRESS, addr);
                    row.put(ContactDBHelper.COL_TEL, phone);
                    row.put(ContactDBHelper.COL_LISTID, listId);

                    db.insert(ContactDBHelper.TABLE_REST_PLAN, null, row);
                }
                helper.close();
                Toast.makeText(this, "일정이 추가되었습니다!", Toast.LENGTH_SHORT).show();
                break;
            case R.id.btnCancel:
                finish();
                break;
        }
    }
}

