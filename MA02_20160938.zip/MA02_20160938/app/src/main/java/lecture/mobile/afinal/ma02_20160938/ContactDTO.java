package lecture.mobile.afinal.ma02_20160938;

public class ContactDTO {
    private long id;
    private String name;
    private String path;
    private String address;
    private String tel;
    private String star;
    private String memo;
    private String listId;

    public ContactDTO(long id, String name, String Path, String address, String star, String memo) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.star = star;
        this.memo = memo;
    }
    public ContactDTO() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getStar() {
        return star;
    }

    public void setStar(String star) {
        this.star = star;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getListId() {
        return listId;
    }

    public void setListId(String listId) {
        this.listId = listId;
    }

    @Override
    public String toString() {
        return "ContactDTO{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", path='" + path + '\'' +
                ", address='" + address + '\'' +
                ", tel='" + tel + '\'' +
                ", star='" + star + '\'' +
                ", memo='" + memo + '\'' +
                ", listId='" + listId + '\'' +
                '}';
    }
}
