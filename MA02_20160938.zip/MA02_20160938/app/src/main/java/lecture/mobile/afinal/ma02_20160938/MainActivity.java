package lecture.mobile.afinal.ma02_20160938;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*//배경을 지정할 수 있는 배경관리자 객체를 구합니다.
        final WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
        //그리기 객체를 생성합니다. 그리고 현재 바탕화면의 이미지를 셋팅합니다.
        final Drawable wallpaperDrawable = wallpaperManager.getDrawable();
        //이미지 불러오기 객체를 생성합니다.
        final ImageView imageView = (ImageView) findViewById(R.id.imageview);
        //이미지 캐싱설정을 해줍니다. 이후에 설정된 이미지를 가져올때,
        //getDrawingCache() 로 비트맵 이미지 데이터를 가져오면 됩니다.
        imageView.setDrawingCacheEnabled(true);
        //이미지 객체에, 바탕화면 이미지를 셋팅합니다.
        imageView.setImageDrawable(wallpaperDrawable);
        //셋팅된 바탕화면 이미지 객체에서 비트맵데이터를 가져와 바탕화면에
        //비트맵 출력을 해줍니다. 이 부분이 실제로 바탕화면을 바꿔주게 됩니다.
         wallpaperManager.setBitmap(imageView.getDrawingCache());*/



    }

    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.button:
                intent = new Intent(MainActivity.this, AllContactsActivity.class);
                startActivity(intent);
                break;
            case R.id.button2:
                intent = new Intent(MainActivity.this, AllMemoryActivity.class);
                startActivity(intent);
                break;
            case R.id.button3 :
                /*intent = new Intent(MainActivity.this, InsertPlanActivity.class);
                */
                intent = new Intent(MainActivity.this, AllPlanActivity.class);
                startActivity(intent);
                break;
            case R.id.btnLeft:
                startActivity(new Intent(MainActivity.this, AllContactsOnMapActivity.class));
                overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_left);
                finish();
                break;
        }
    }
}

