package lecture.mobile.afinal.ma02_20160938;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class SearchPlanDetailActivity extends AppCompatActivity {
    ListView lvList;
    MyPlanDetailAdapter adapter;
    ArrayList<MyTourData> resultList;
    String address;     //openAPI를 요청할 url주소
    EditText etSearch;

    String target;      //etSearch에 입력한 검색할 값
    String keyword;     //target을 utf-8로 인코딩한 값
    Intent intent = null;
    int id;
    String area;
    ContactDBHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_plan_detail);

        intent = getIntent();
        id = intent.getIntExtra("_id", -1);
        area = intent.getStringExtra("area");
        Log.d("area",area);
        helper = new ContactDBHelper(this);

        resultList = new ArrayList<MyTourData>();
        adapter = new MyPlanDetailAdapter(this, R.layout.custom_adpter_view_plan, resultList);

        lvList = (ListView)findViewById(R.id.listView);
        lvList.setAdapter(adapter);

        etSearch = (EditText)findViewById(R.id.etSearch);
        etSearch.setText(area);

        lvList.setOnItemClickListener(new AdapterView.OnItemClickListener() {       //리스트중 한 항목을 클릭하면 인텐트를 호출
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long l) {
                SQLiteDatabase db = helper.getWritableDatabase();

                String title = resultList.get(pos).getTitle();
                String addr = resultList.get(pos).getAddr();
                String tel = resultList.get(pos).getTel();

                ContentValues row = new ContentValues();
                row.put(ContactDBHelper.COL_NAME, title);
                row.put(ContactDBHelper.COL_ADDRESS, addr);
                row.put(ContactDBHelper.COL_TEL, tel);

                db.insert(ContactDBHelper.TABLE_TOUR_PLAN, null, row);
                helper.close();

                Toast.makeText(SearchPlanDetailActivity.this, "여행지 위시리스트가 추가되었습니다!", Toast.LENGTH_SHORT).show();

            }
        });
    }

    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btnSearch:        //검색버튼 누르면
                target = etSearch.getText().toString();

                try {
                    keyword = URLEncoder.encode(target, "UTF-8");       //검색할 키워드를 인코딩함
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }


                if (target.equals("")) Toast.makeText(this, "검색어를 입력하세요.", Toast.LENGTH_SHORT).show(); // 입력값이 없을 경우 토스트 띄우기
                else {
                    address = "http://api.visitkorea.or.kr/openapi/service/rest/KorService/searchKeyword?";
                    address += "serviceKey=xoflh7EFyBviOqt%2FgsA5oi3qCbGa6JFnjFnDQC3ZwHpYEaY2cuRsoRLtzIflwugxZs5hZjoEwj2unEC8QtJz5g%3D%3D";
                    address += "&MobileApp=report02_02_20160938&MobileOS=AND&keyword=";
                    address += keyword;

                    new NetworkAsyncTask().execute(address);
                }    // address에 입력한 검색어를 인코딩한 값을 결합한 후 AsyncTask 실행
                break;

        }
    }

    //      openAPI 요청
    class NetworkAsyncTask extends AsyncTask<String, Integer, String> {

        public final static String TAG = "NetworkAsyncTask";
        public final static int TIME_OUT = 10000;

        ProgressDialog progressDlg;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDlg = ProgressDialog.show(SearchPlanDetailActivity.this, "Wait", "Downloading...");     // 진행상황 다이얼로그 출력
        }

        @Override
        protected String doInBackground(String... strings) {
            String address = strings[0];
            StringBuilder result = new StringBuilder();
            BufferedReader br = null;
            HttpURLConnection conn = null;

            try {
                URL url = new URL(address);
                conn = (HttpURLConnection)url.openConnection();

                if (conn != null) {
                    conn.setConnectTimeout(TIME_OUT);
                    conn.setUseCaches(false);
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                        for (String line = br.readLine(); line != null; line = br.readLine()) {
                            result.append(line + '\n');
                        }
                    }
                }

            } catch (MalformedURLException ex) {
                ex.printStackTrace();
                cancel(false);
            } catch (Exception ex) {
                ex.printStackTrace();
                cancel(false);
            } finally {
                try {
                    if (br != null)  br.close();
                    if (conn != null) conn.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return result.toString();
        }

        @Override
        protected void onPostExecute(String result) {
//          parser 생성 및 parsing 수행
            MyXmlParser parser = new MyXmlParser();
            resultList = parser.parse2(result);

//            어댑터에 이전에 보여준 데이터가 있을 경우 클리어
            if (!resultList.isEmpty()) adapter.clear();

//            리스트뷰에 연결되어 있는 어댑터에 parsing 결과 ArrayList 를 추가
            adapter.addAll(resultList);

//            진행상황 다이얼로그 종료
            progressDlg.dismiss();
        }


        @Override
        protected void onCancelled() {
            super.onCancelled();
            Toast.makeText(SearchPlanDetailActivity.this, "Error!!!", Toast.LENGTH_SHORT).show();
            progressDlg.dismiss();
        }
    }
}
