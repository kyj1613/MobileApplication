package lecture.mobile.afinal.ma02_20160938;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.StringReader;
import java.util.ArrayList;

public class MyXmlParser {

    //    xml에서 읽어들일 태그를 구분한 enum  → 정수값 등으로 구분하지 않고 가독성 높은 방식을 사용
    private enum TagType { NONE, TITLE, ADDR, TEL };        // 해당없음, title, addr1, tel
    private enum TagType2 { NONE, TITLE, ADDR, CATEGORY, TEL };  // 해당없음, title, category, tel
    //    parsing 대상인 tag를 상수로 선언
    private final static String ITEM_TAG = "item";
    private final static String TITLE_TAG = "title";    //관광지 명 및 맛집 이름
    private final static String ADDR_TAG = "addr";     //관광지 및 맛집 주소
    private final static String ADDR1_TAG = "addr1";     //관광지 및 맛집 주소
    private final static String CTGR_TAG = "category";  //맛집의 음식 종류
    private final static String TEL_TAG = "tel";        //관광지 전화번호
    private final static String TELEPHONE_TAG = "telephone";    //맛집 전화번호

    private XmlPullParser parser;


    public MyXmlParser() {

        //        파서 준비
        XmlPullParserFactory factory = null;
        try {
            factory = XmlPullParserFactory.newInstance();
            parser = factory.newPullParser();
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        }
    }

    //맛집에 대한 xml파일 파싱
    public ArrayList<MyEatData> parse(String xml) {
        ArrayList<MyEatData> resultList = new ArrayList();
        MyEatData dbo = null;

//        태그를 구분하기 위한 enum 변수 초기화
        TagType2 tagType2 = TagType2.NONE;

        try {
            parser.setInput(new StringReader(xml));

//          태그 유형 구분 변수 준비
            int eventType = parser.getEventType();

//          parsing 수행 - for 문 또는 while 문으로 구성
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_DOCUMENT:
                        break;
                    case XmlPullParser.END_DOCUMENT:
                        break;
                    case XmlPullParser.START_TAG:
                        if (parser.getName().equals(ITEM_TAG)) {    // 새로운 항목을 표현하는 태그를 만났을 경우 dto 객체 생성
                            dbo = new MyEatData();                   // 맛집에 대한 실질적인 정보가 <item> </item>사이에 있음
                        } else if (parser.getName().equals(TITLE_TAG)) {
                            if(dbo != null)                         //xml파일에 title태그가 두번 있기 때문에 맛집 이름에 해당하는 title태그일때
                                tagType2 = TagType2.TITLE;           //tagType 변경
                        } else if (parser.getName().equals(ADDR_TAG)) {
                            tagType2 = TagType2.ADDR;
                        } else if (parser.getName().equals(CTGR_TAG)) {
                            tagType2 = TagType2.CATEGORY;
                        } else if (parser.getName().equals(TELEPHONE_TAG)) {
                            tagType2 = TagType2.TEL;
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        if (parser.getName().equals(ITEM_TAG)) {    //</item>을 만나면 dbo2객체를
                            resultList.add(dbo);                    //arraylist에 저장한 후
                            dbo = null;                              //null로 만들어줌
                        }
                        break;
                    case XmlPullParser.TEXT:
                        switch (tagType2) {       // 태그의 유형에 따라 dto 에 값 저장
                            case TITLE:
                                dbo.setTitle(parser.getText());
                                break;
                            case ADDR:
                                dbo.setAddr(parser.getText());
                                break;
                            case CATEGORY:
                                dbo.setCategory(parser.getText());
                                break;
                            case TEL:
                                dbo.setTel("(Tel)" + parser.getText());
                                break;
                        }
                        tagType2 = TagType2.NONE;
                        break;
                }
                eventType = parser.next();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultList;
    }

    //맛집에 대한 xml파일 파싱
    public ArrayList<MyTourData> parse2(String xml) {
        ArrayList<MyTourData> resultList = new ArrayList();
        MyTourData dbo = null;

//        태그를 구분하기 위한 enum 변수 초기화
        TagType tagType = TagType.NONE;

        try {
            parser.setInput(new StringReader(xml));

//          태그 유형 구분 변수 준비
            int eventType = parser.getEventType();

//          parsing 수행 - for 문 또는 while 문으로 구성
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_DOCUMENT:
                        break;
                    case XmlPullParser.END_DOCUMENT:
                        break;
                    case XmlPullParser.START_TAG:
                        if (parser.getName().equals(ITEM_TAG)) {    // 새로운 항목을 표현하는 태그를 만났을 경우 dto 객체 생성
                            dbo = new MyTourData();                   // 맛집에 대한 실질적인 정보가 <item> </item>사이에 있음
                        } else if (parser.getName().equals(TITLE_TAG)) {
                            if(dbo != null)                         //xml파일에 title태그가 두번 있기 때문에 맛집 이름에 해당하는 title태그일때
                                tagType = TagType.TITLE;           //tagType 변경
                        } else if (parser.getName().equals(ADDR1_TAG)) {
                            tagType = TagType.ADDR;
                        } else if (parser.getName().equals(TELEPHONE_TAG)) {
                            tagType = TagType.TEL;
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        if (parser.getName().equals(ITEM_TAG)) {    //</item>을 만나면 dbo2객체를
                            resultList.add(dbo);                    //arraylist에 저장한 후
                            dbo = null;                              //null로 만들어줌
                        }
                        break;
                    case XmlPullParser.TEXT:
                        switch (tagType) {       // 태그의 유형에 따라 dto 에 값 저장
                            case TITLE:
                                dbo.setTitle(parser.getText());
                                break;
                            case ADDR:
                                dbo.setAddr(parser.getText());
                                break;
                            case TEL:
                                dbo.setTel("(Tel)" + parser.getText());
                                break;
                        }
                        tagType = TagType.NONE;
                        break;
                }
                eventType = parser.next();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultList;
    }

    //맛집에 대한 xml파일 파싱
    public ArrayList<MyRestData> parse3(String xml) {
        ArrayList<MyRestData> resultList = new ArrayList();
        MyRestData dbo = null;

//        태그를 구분하기 위한 enum 변수 초기화
        TagType tagType = TagType.NONE;

        try {
            parser.setInput(new StringReader(xml));

//          태그 유형 구분 변수 준비
            int eventType = parser.getEventType();

//          parsing 수행 - for 문 또는 while 문으로 구성
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_DOCUMENT:
                        break;
                    case XmlPullParser.END_DOCUMENT:
                        break;
                    case XmlPullParser.START_TAG:
                        if (parser.getName().equals(ITEM_TAG)) {    // 새로운 항목을 표현하는 태그를 만났을 경우 dto 객체 생성
                            dbo = new MyRestData();                   // 맛집에 대한 실질적인 정보가 <item> </item>사이에 있음
                        } else if (parser.getName().equals(TITLE_TAG)) {
                            if(dbo != null)                         //xml파일에 title태그가 두번 있기 때문에 맛집 이름에 해당하는 title태그일때
                                tagType = TagType.TITLE;           //tagType 변경
                        } else if (parser.getName().equals(ADDR_TAG)) {
                            tagType = TagType.ADDR;
                        } else if (parser.getName().equals(TELEPHONE_TAG)) {
                            tagType = TagType.TEL;
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        if (parser.getName().equals(ITEM_TAG)) {    //</item>을 만나면 dbo2객체를
                            resultList.add(dbo);                    //arraylist에 저장한 후
                            dbo = null;                              //null로 만들어줌
                        }
                        break;
                    case XmlPullParser.TEXT:
                        switch (tagType) {       // 태그의 유형에 따라 dto 에 값 저장
                            case TITLE:
                                dbo.setTitle(parser.getText());
                                break;
                            case ADDR:
                                dbo.setAddr(parser.getText());
                                break;
                            case TEL:
                                dbo.setTel("(Tel)" + parser.getText());
                                break;
                        }
                        tagType = TagType.NONE;
                        break;
                }
                eventType = parser.next();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultList;
    }
}
