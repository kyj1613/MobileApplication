package lecture.mobile.afinal.ma02_20160938;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;

public class MyDetailAdapter extends RecyclerView.Adapter<MyDetailAdapter.ViewHolder> {
    Context context;
    ArrayList<ContactDTO> contactList; //공지사항 정보 담겨있음

    public MyDetailAdapter(Context context, ArrayList<ContactDTO> contactList) {
        this.context = context;
        this.contactList = contactList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //recycler view에 반복될 아이템 레이아웃 연결
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_card_view, parent, false);
        return new ViewHolder(v);
    }

    /** 정보 및 이벤트 처리는 이 메소드에서 구현 **/
    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        ContactDTO contactItem = contactList.get(position);
        Log.d("POSITION", String.valueOf(position));

        holder.tvName.setText(contactItem.getName()); //작성자
        holder.tvAddress.setText(contactItem.getAddress()); //제목
        holder.rbRating.setRating(Float.parseFloat(contactItem.getStar())); //내용 일부
        holder.tvMemo.setText(contactItem.getMemo()); //작성일
        /*String path = contactItem.getPath();
        Log.d("PATH", path);
        File imgFile = new  File(path);
        if(imgFile.exists()) {
            Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
            holder.ivPhoto.setImageBitmap(myBitmap);
        }*/
    }

    @Override
    public int getItemCount() {Log.e("[size]", String.valueOf(contactList.size()));
        return this.contactList.size();
    }
    /** item layout 불러오기 **/
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName;
        ImageView ivPhoto;
        TextView tvAddress;
        RatingBar rbRating;
        TextView tvMemo;
        CardView cv;

        public ViewHolder(View v) {
            super(v);
            tvName = (TextView) v.findViewById(R.id.tvName);
            ivPhoto = (ImageView) v.findViewById(R.id.ivPhoto);
            tvAddress = (TextView) v.findViewById(R.id.tvAddress);
            rbRating = (RatingBar) v.findViewById(R.id.rating);
            tvMemo = (TextView) v.findViewById(R.id.tvMemo);
            cv = (CardView) v.findViewById(R.id.cvContact);
        }
    }
}

